
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.tsx';
import { Logger } from './lib/logger.ts';

// Inicializa los manejadores de errores globales que enviarán errores no capturados a nuestra consola.
Logger.init();

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);